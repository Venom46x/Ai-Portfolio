class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        footer {
          background: #111827;
          color: rgba(255, 255, 255, 0.7);
          padding: 3rem 2rem;
          text-align: center;
          border-top: 1px solid rgba(255, 255, 255, 0.05);
        }
        .footer-content {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2rem;
        }
        .footer-logo {
          font-size: 1.5rem;
          font-weight: bold;
          background: linear-gradient(to right, #7b46f5, #c94ff7);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .footer-links {
          display: flex;
          gap: 2rem;
          flex-wrap: wrap;
          justify-content: center;
        }
        .footer-link {
          color: rgba(255, 255, 255, 0.7);
          text-decoration: none;
          transition: color 0.3s ease;
        }
        .footer-link:hover {
          color: #7b46f5;
        }
        .footer-social {
          display: flex;
          gap: 1.5rem;
        }
        .social-icon {
          color: rgba(255, 255, 255, 0.7);
          transition: all 0.3s ease;
        }
        .social-icon:hover {
          color: #7b46f5;
          transform: translateY(-3px);
        }
        .copyright {
          font-size: 0.875rem;
          margin-top: 2rem;
        }
      </style>
      <footer>
        <div class="footer-content">
          <div class="footer-logo">PixelPulse</div>
          <div class="footer-links">
            <a href="#projects" class="footer-link">Projects</a>
            <a href="#qualifications" class="footer-link">Experience</a>
            <a href="#certificates" class="footer-link">Certificates</a>
            <a href="#contact" class="footer-link">Contact</a>
          </div>
          <div class="footer-social">
            <a href="#" class="social-icon"><i data-feather="github"></i></a>
            <a href="#" class="social-icon"><i data-feather="linkedin"></i></a>
            <a href="#" class="social-icon"><i data-feather="twitter"></i></a>
            <a href="#" class="social-icon"><i data-feather="dribbble"></i></a>
          </div>
          <div class="copyright">
            &copy; ${new Date().getFullYear()} PixelPulse Portfolio. All rights reserved.
          </div>
        </div>
      </footer>
    `;
  }
}
customElements.define('custom-footer', CustomFooter);